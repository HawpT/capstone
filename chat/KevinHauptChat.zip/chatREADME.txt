Chat by Kevin Haupt
FOR WINDOWS MACHINES

How To:

run ChatServer.exe
type in a server address

run chatroom.exe
select your preferences
Usages:
connect <address> <username> 		//connect to a server at address
connect <username> 			//will default to localhost:8000
<messsage> 				//general message
/w <targetuser> <message> 		//private message to targetuser
disconnect 				//safely disconnects the client from the server, ready for new session

					//client will automatically send disconnect if you close the window